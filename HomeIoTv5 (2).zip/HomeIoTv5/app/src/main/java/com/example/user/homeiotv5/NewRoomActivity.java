package com.example.user.homeiotv5;

import android.content.Intent;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class NewRoomActivity extends AppCompatActivity {

    String id;
    EditText RoomName;
    CheckBox Temperature, Humidity, Lumosity;
    Switch switch1, switch2, switch3, switch4, switch5, switch6;
    Button Submit;
    List<Boolean> switches = new ArrayList<>();
    List<Boolean> actuator = new ArrayList<>();
    List<String> spin = new ArrayList<>();
    Spinner roomTypeSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_room);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        System.out.println("my id:" + id);

        spin.add("1");
        spin.add("2");
        spin.add("3");
        spin.add("4");

        roomTypeSpinner= findViewById(R.id.dropdown);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, spin);
        roomTypeSpinner.setAdapter(dataAdapter);

        RoomName = (EditText) findViewById(R.id.roomnameedittext);
        Temperature = (CheckBox) findViewById(R.id.checkBoxTemperature);
        Humidity = (CheckBox) findViewById(R.id.checkBoxHumidity);
        Lumosity = (CheckBox) findViewById(R.id.checkBoxLumosity);
        switch1 = (Switch) findViewById(R.id.switch1);
        switch2 = (Switch) findViewById(R.id.switch2);
        switch3 = (Switch) findViewById(R.id.switch3);
        switch4 = (Switch) findViewById(R.id.switch4);
        switch5 = (Switch) findViewById(R.id.switch5);
        switch6 = (Switch) findViewById(R.id.switch6);
        Submit = (Button) findViewById(R.id.button);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roomname = RoomName.getText().toString();

                if (Temperature.isChecked()) {
                    actuator.add(true);
                } else {
                    actuator.add(false);
                }
                if (Humidity.isChecked()) {
                    actuator.add(true);
                } else {
                    actuator.add(false);
                }
                if (Lumosity.isChecked()) {
                    actuator.add(true);
                } else {
                    actuator.add(false);
                }
                if (switch1.isChecked()) {
                    switches.add(true);
                } else {
                    switches.add(false);
                }
                if (switch2.isChecked()) {
                    switches.add(true);
                } else {
                    switches.add(false);
                }
                if (switch3.isChecked()) {
                    switches.add(true);
                } else {
                    switches.add(false);
                }
                if (switch4.isChecked()) {
                    switches.add(true);
                } else {
                    switches.add(false);
                }
                if (switch5.isChecked()) {
                    switches.add(true);
                } else {
                    switches.add(false);
                }
                if (switch6.isChecked()) {
                    switches.add(true);
                } else {
                    switches.add(false);
                }
                for (int i = 0; i < switches.size(); i++) {
                    System.out.println("Switches " + i + " is  " + switches.get(i));
                }

                if (roomname.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please fill the room's name and type.", Toast.LENGTH_SHORT).show();
                } else {

                    submitFormServer(roomname);
                }
            }
        });
    }

    private String submitFormServer(final String roomname) {

        final String[] response = {""};

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    response[0] = insertToDB(roomname);
                } catch (Exception e) {
                    Log.i("Thread Exce", e.toString());
                } finally {

                    /*if (response.equals("1")) {
                        Toast.makeText(getApplicationContext(), "Η ενημέρωση έγινε επιτυχώς.", Toast.LENGTH_LONG).show();
                        finish();
                    } else
                        Toast.makeText(getApplicationContext(), "Server connection failed.", Toast.LENGTH_LONG).show();*/
                }
            }
        }).start();
        return response[0];
    }

    private String insertToDB(String roomname) {
        String myStr = "";
        myStr += id + "///";
        myStr += roomname + "///";
        myStr += roomTypeSpinner.getSelectedItem().toString() + "///";

        for (int i = 0; i < actuator.size(); i++) {
            //if (switches.get(i)){
            myStr += actuator.get(i) + "///";
        }

        for (int i = 0; i < switches.size(); i++) {
            //if (switches.get(i)){
            myStr += switches.get(i) + "///";
        }
        System.out.println("Form: " + myStr);
        try {
            String urL = "http://192.168.1.3/homeiot/new_room.php";
            URL url = new URL(urL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);

            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

            //ta dedomena pou 8a steiloume ston server
            String data = URLEncoder.encode("myStr", "UTF-8") + "=" + URLEncoder.encode(myStr, "UTF-8");

            Log.i("data", data);
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();

            outputStream.close();

            // to answer apo ton server
            InputStream inputstream = httpURLConnection.getInputStream();
            StringBuilder result = inputToString(inputstream);

            return result.toString();

        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    // metatroph tou response se StringBuilder
    private StringBuilder inputToString(InputStream input) {
        String line;

        StringBuilder answer = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(input));

        try {
            while ((line = br.readLine()) != null) {
                answer.append(line);
            }
            System.out.println("form check " + answer);
        } catch (Exception e) {
            Log.i("Error on inputtoStr: ", e.toString());
        }
        return answer;
    }
}