package com.example.user.homeiotv5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

public class LogInActivity extends AppCompatActivity {

    EditText email, password;
    Button loginbutton;
    String id;

    Global global;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        global = ((Global) getApplicationContext());

        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);

        loginbutton = (Button) findViewById(R.id.loginbutton);
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = email.getText().toString();
                String pass = password.getText().toString();

                if (user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Παρακαλώ συμπληρώστε όλες τις πληροφορίες.", Toast.LENGTH_SHORT).show();
                } else {
                    logInServer(user, pass);
                }
            }
        });
    }
    void logInServer(final String user, final String pass) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                String res = "";
                try {
                    res = login(user, pass);

                } catch (Exception e) {
                    Log.i("Thread Exception", e.toString());
                } finally {

                    final String finalRes = res;
                    LogInActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (finalRes.equals("1")) {
                                Intent intent = new Intent(LogInActivity.this, MainActivity.class);
                                intent.putExtra("id",id);
                                LogInActivity.this.startActivity(intent);
                                finish();
                            } else
                                Toast.makeText(getApplicationContext(), "Λάθος Πληροφορίες.", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            }
        }).start();
    }
    String login(String user, String pass) {
        try {
            String urL = "http://192.168.1.4/homeiot/login.php";
            URL url = new URL(urL);
            HttpURLConnection httpURLConnection =(HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);

            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

            //ta dedomena pou 8a steiloume ston server
            String data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8") + "&" +
                    URLEncoder.encode("pass", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8");


            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();


            outputStream.close();

            // to answer apo ton server
            InputStream inputstream = httpURLConnection.getInputStream();
            StringBuilder result = inputToString(inputstream);

            Log.i ("resu from server",result.toString());
            String[] parts = result.toString().split("///");
            System.out.println("id " + parts[1]);
            id=parts[1];

            return parts[0];


        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
    // metatroph tou response se StringBuilder
    private StringBuilder inputToString(InputStream input) {
        String line;

        StringBuilder answer = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(input));

        try {
            while ((line = br.readLine()) != null) {
                answer.append(line);
            }
            System.out.println(answer);
        } catch (Exception e) {
            Log.i("Error on input to Str: ", e.toString());
        }
        return answer;
    }
}
