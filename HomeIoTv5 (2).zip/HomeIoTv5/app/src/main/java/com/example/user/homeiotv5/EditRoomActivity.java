package com.example.user.homeiotv5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class EditRoomActivity extends AppCompatActivity {

    String id;
    int roomID;
    EditText RoomName;
    CheckBox Temperature, Humidity, Lumosity;
    Switch switch1, switch2, switch3, switch4, switch5, switch6;

    Button Submit;

    Global global;

    Room room;
    Spinner RoomType;

    //List<Boolean> switches = new ArrayList<>();
    //List<Boolean> actuator = new ArrayList<>();
    //List<Boolean> roomtype = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_room);

        global = ((Global) getApplicationContext());

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        roomID = intent.getIntExtra("RoomID", -1);
        System.out.println("my id:" + id);

        for (int i = 0; i < global.GlobalRooms.size(); i++) {
            System.out.println("object id is " + global.GlobalRooms.get(i).getId() + "  positipn is " + roomID);

            if (roomID == Integer.parseInt(global.GlobalRooms.get(i).getId()) - 1) {
                room = global.GlobalRooms.get(i);
                break;
            }
        }
        System.out.print("object name is " + room.getName());

        List<String> roomTypeSpinner = new ArrayList<>();

        roomTypeSpinner.add("1");
        roomTypeSpinner.add("2");
        roomTypeSpinner.add("3");
        roomTypeSpinner.add("4");


        for (int i = 0; i < roomTypeSpinner.size(); i++) {
            if (roomTypeSpinner.get(i).equals(room.getType())) {
                roomTypeSpinner.remove(i);
                roomTypeSpinner.add(0, room.getType());
            }
        }


        RoomName = (EditText) findViewById(R.id.roomnameedittext);
        RoomName.setText(room.getName());

        RoomType = findViewById(R.id.dropdown1);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, roomTypeSpinner);
        RoomType.setAdapter(dataAdapter);

        Temperature = (CheckBox) findViewById(R.id.checkBoxTemperature);
        Temperature.setChecked(transformStringToBoolean(room.getTemperatureExists()));

        Humidity = (CheckBox) findViewById(R.id.checkBoxHumidity);
        Humidity.setChecked(transformStringToBoolean(room.getHumidityExists()));
        Lumosity = (CheckBox) findViewById(R.id.checkBoxLumosity);
        Lumosity.setChecked(transformStringToBoolean(room.getLuminocityExists()));
        switch1 = (Switch) findViewById(R.id.switch1);
        switch1.setChecked(transformStringToBoolean(room.getSwitch1Exists()));
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                room.setSwitch1Exists(b+"");
            }
        });
        switch2 = (Switch) findViewById(R.id.switch2);
        switch2.setChecked(transformStringToBoolean(room.getSwitch2Exists()));
        switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                room.setSwitch2Exists(b+"");
            }
        });
        switch3 = (Switch) findViewById(R.id.switch3);
        switch3.setChecked(transformStringToBoolean(room.getSwitch3Exists()));
        switch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                room.setSwitch3Exists(b+"");
            }
        });
        switch4 = (Switch) findViewById(R.id.switch4);
        switch4.setChecked(transformStringToBoolean(room.getSwitch4Exists()));
        switch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                room.setSwitch4Exists(b+"");
            }
        });
        switch5 = (Switch) findViewById(R.id.switch5);
        switch5.setChecked(transformStringToBoolean(room.getSwitch5Exists()));
        switch5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                room.setSwitch5Exists(b+"");
            }
        });
        switch6 = (Switch) findViewById(R.id.switch6);
        switch6.setChecked(transformStringToBoolean(room.getSwitch6Exists()));
        switch6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                room.setSwitch6Exists(b+"");
            }
        });
        Submit = (Button) findViewById(R.id.button);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                room.setName(RoomName.getText().toString());
                room.setType(RoomType.getSelectedItem().toString());
                room.setTemperatureExists(Temperature.getText().toString());
                room.setHumidityExists(Humidity.getText().toString());
                room.setLuminocityExists(Lumosity.getText().toString());
                updateRooms();
            }
        });

    }


    public  void updateRooms(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    insertToDB();
                } catch (Exception e) {
                    Log.i("Thread Exce", e.toString());
                } finally {

                }
            }
        }).start();

    }

    private String insertToDB() {
        String myStr = "";

        myStr += room.getId() + "///";
        myStr += room.getName() + "///";
        myStr += room.getType() + "///";

        myStr += room.getHumidityExists() + "///";
        myStr += room.getTemperatureExists() + "///";
        myStr += room.getLuminocityExists() + "///";



        myStr += room.getSwitch1Exists() + "///";
        myStr += room.getSwitch2Exists() + "///";
        myStr += room.getSwitch3Exists() + "///";
        myStr += room.getSwitch4Exists() + "///";
        myStr += room.getSwitch5Exists() + "///";
        myStr += room.getSwitch6Exists() + "///";


        System.out.println("Form: " + myStr);
        try {
            String urL = "http://192.168.1.4/homeiot/edit_room.php";
            URL url = new URL(urL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);

            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

            //ta dedomena pou 8a steiloume ston server
            String data = URLEncoder.encode("myStr", "UTF-8") + "=" + URLEncoder.encode(myStr, "UTF-8");

            Log.i("data", data);
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();

            outputStream.close();

            // to answer apo ton server
            InputStream inputstream = httpURLConnection.getInputStream();
            StringBuilder result = inputToString(inputstream);

            return result.toString();

        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


    private Boolean transformStringToBoolean(String string) {
        if(string.equals("false"))
            return false;

        return true;
    }

    // response from server to StringBuilder
    public StringBuilder inputToString(InputStream input) {
        String line;

        StringBuilder answer = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(input));

        try {
            while ((line = br.readLine()) != null) {
                answer.append(line);
            }
        } catch (Exception e) {
            Log.i("Error on inputtoStr: ", e.toString());
        }
        return answer;
    }

}

