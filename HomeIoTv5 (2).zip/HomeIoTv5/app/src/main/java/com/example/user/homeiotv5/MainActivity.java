package com.example.user.homeiotv5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.opengles.GL;

public class MainActivity extends AppCompatActivity {

    String id;
    Button addnewroom;
    ListView roomsListView;
    List<Room> rooms;
    ListAdapter adapter;

    Global global;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        global =((Global) getApplicationContext());

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        System.out.println("my id:" + id);

        roomsListView = findViewById(R.id.allRooms);

        rooms= new ArrayList<>();

        addnewroom = findViewById(R.id.addnewroom);
        addnewroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentnewroom = new Intent(MainActivity.this, NewRoomActivity.class);
                intentnewroom.putExtra("id",id);
                startActivity(intentnewroom);
            }
        });

        downloadRooms();
        roomsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                for(int j =0 ; j<global.GlobalRooms.size();j++){

                    System.out.println("object id is " + global.GlobalRooms.get(j).getId()+"  positipn is "+ i);

                }

                Intent intent = new Intent(MainActivity.this, ViewRoomActivity.class);
                intent.putExtra("id",id);
                intent.putExtra("RoomID",i);
                startActivity(intent);
            }
        });
    }

    public  void downloadRooms(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                   rooms= downloadAPI();
                } catch (Exception e) {
                    Log.i("Thread Exce", e.toString());
                } finally {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            global.GlobalRooms=rooms;

                            adapter = new ListAdapter(rooms,getApplicationContext());
                            roomsListView.setAdapter( adapter);
                        }
                    });
                }
            }
        }).start();

    }

    // function to download buoys from DB
    public List<Room> downloadAPI() {
        List<Room> listWithBuoys = new ArrayList<>();

        String urL = "http://192.168.1.4/homeIoT/view_room.php";

        try {
            //http request
            URL url = new URL(urL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoInput(true);

            InputStream inputstream = httpURLConnection.getInputStream();

            //response to stringBuilder
            StringBuilder result = inputToString(inputstream);
            Log.i("response", result.toString());

            // response is on json
            JSONObject jsonResponse = new JSONObject(result.toString());
            JSONArray jsonMainNode = jsonResponse.optJSONArray("rooms");

            //Helpers
            String id, name,type,TemperatureExists,HumidityExists,LuminocityExists,Temperature,Humidity,Luminocity,Switch1Exists,
            Switch1,Switch2Exists,Switch2,Switch3Exists,Switch3,Switch4Exists,Switch4,Switch5Exists,Switch5,Switch6Exists,Switch6;
            //json parsing
            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONArray jsonArray = jsonMainNode.getJSONArray(i);
                id = jsonArray.getString(0);
                name = jsonArray.getString(1);
                type = jsonArray.getString(2);
                TemperatureExists= jsonArray.getString(3);
                HumidityExists = jsonArray.getString(4);
                LuminocityExists= jsonArray.getString(5);
                Temperature= jsonArray.getString(6);
                Humidity= jsonArray.getString(7);
                Luminocity= jsonArray.getString(8);
                Switch1Exists= jsonArray.getString(9);
                Switch1= jsonArray.getString(10);
                Switch2Exists= jsonArray.getString(11);
                Switch2= jsonArray.getString(12);
                Switch3Exists= jsonArray.getString(13);
                Switch3= jsonArray.getString(14);
                Switch4Exists= jsonArray.getString(15);
                Switch4= jsonArray.getString(16);
                Switch5Exists= jsonArray.getString(17);
                Switch5= jsonArray.getString(18);
                Switch6Exists= jsonArray.getString(19);
                Switch6= jsonArray.getString(20);

                // populate Buoy's list
                listWithBuoys.add(new Room(id,name,type,TemperatureExists,HumidityExists,LuminocityExists,Temperature,Humidity,Luminocity,Switch1Exists,Switch1,Switch2Exists,Switch2,Switch3Exists,Switch3,Switch4Exists,Switch4,Switch5Exists,Switch5,Switch6Exists,Switch6));
            }


            return listWithBuoys;

        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    // response from server to StringBuilder
    public StringBuilder inputToString(InputStream input) {
        String line;

        StringBuilder answer = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(input));

        try {
            while ((line = br.readLine()) != null) {
                answer.append(line);
            }
        } catch (Exception e) {
            Log.i("Error on inputtoStr: ", e.toString());
        }
        return answer;
    }

}