package com.example.user.homeiotv5;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 27/1/2018.
 */

public class Global extends Application{
    public List<Room> GlobalRooms = new ArrayList<>();
}
