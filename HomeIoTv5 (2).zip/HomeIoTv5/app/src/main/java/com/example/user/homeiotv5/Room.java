package com.example.user.homeiotv5;

/**
 * Created by User on 27/1/2018.
 */

public class Room {

    String id,name,type,TemperatureExists,HumidityExists,LuminocityExists,Temperature,Humidity,Luminocity,Switch1Exists,
            Switch1,Switch2Exists,Switch2,Switch3Exists,Switch3,Switch4Exists,Switch4,Switch5Exists,Switch5,Switch6Exists,Switch6;

    public Room(String id, String name, String type, String temperatureExists, String humidityExists, String luminocityExists, String temperature, String humidity, String luminocity, String switch1Exists, String switch1, String switch2Exists, String switch2, String switch3Exists, String switch3, String switch4Exists, String switch4, String switch5Exists,String switch5, String switch6Exists, String switch6) {
        this.id = id;
        this.name = name;
        this.type = type;
        TemperatureExists = temperatureExists;
        HumidityExists = humidityExists;
        LuminocityExists = luminocityExists;
        Temperature = temperature;
        Humidity = humidity;
        Luminocity = luminocity;
        Switch1Exists = switch1Exists;
        Switch1 = switch1;
        Switch2Exists = switch2Exists;
        Switch2 = switch2;
        Switch3Exists = switch3Exists;
        Switch3 = switch3;
        Switch4Exists = switch4Exists;
        Switch4 = switch4;
        Switch5Exists = switch5Exists;
        Switch5 = switch5;
        Switch6Exists = switch6Exists;
        Switch6 = switch6;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTemperatureExists() {
        return TemperatureExists;
    }

    public void setTemperatureExists(String temperatureExists) {
        TemperatureExists = temperatureExists;
    }

    public String getHumidityExists() {
        return HumidityExists;
    }

    public void setHumidityExists(String humidityExists) {
        HumidityExists = humidityExists;
    }

    public String getLuminocityExists() {
        return LuminocityExists;
    }

    public void setLuminocityExists(String luminocityExists) {
        LuminocityExists = luminocityExists;
    }

    public String getTemperature() {
        return Temperature;
    }

    public void setTemperature(String temperature) {
        Temperature = temperature;
    }

    public String getHumidity() {
        return Humidity;
    }

    public void setHumidity(String humidity) {
        Humidity = humidity;
    }

    public String getLuminocity() {
        return Luminocity;
    }

    public void setLuminocity(String luminocity) {
        Luminocity = luminocity;
    }

    public String getSwitch1Exists() {
        return Switch1Exists;
    }

    public void setSwitch1Exists(String switch1Exists) {
        Switch1Exists = switch1Exists;
    }

    public String getSwitch1() {
        return Switch1;
    }

    public void setSwitch1(String switch1) {
        Switch1 = switch1;
    }

    public String getSwitch2Exists() {
        return Switch2Exists;
    }

    public void setSwitch2Exists(String switch2Exists) {
        Switch2Exists = switch2Exists;
    }

    public String getSwitch2() {
        return Switch2;
    }

    public void setSwitch2(String switch2) {
        Switch2 = switch2;
    }

    public String getSwitch3Exists() {
        return Switch3Exists;
    }

    public void setSwitch3Exists(String switch3Exists) {
        Switch3Exists = switch3Exists;
    }

    public String getSwitch3() {
        return Switch3;
    }

    public void setSwitch3(String switch3) {
        Switch3 = switch3;
    }

    public String getSwitch4Exists() {
        return Switch4Exists;
    }

    public void setSwitch4Exists(String switch4Exists) {
        Switch4Exists = switch4Exists;
    }

    public String getSwitch4() {
        return Switch4;
    }

    public void setSwitch4(String switch4) {
        Switch4 = switch4;
    }

    public String getSwitch5Exists() {
        return Switch5Exists;
    }

    public void setSwitch5Exists(String switch5Exists) {
        Switch5Exists = switch5Exists;
    }

    public String getSwitch5() {
        return Switch5;
    }

    public void setSwitch5(String switch5) {
        Switch5 = switch5;
    }

    public String getSwitch6Exists() {
        return Switch6Exists;
    }

    public void setSwitch6Exists(String switch6Exists) {
        Switch6Exists = switch6Exists;
    }

    public String getSwitch6() {
        return Switch6;
    }

    public void setSwitch6(String switch6) {
        Switch6 = switch6;
    }
}
