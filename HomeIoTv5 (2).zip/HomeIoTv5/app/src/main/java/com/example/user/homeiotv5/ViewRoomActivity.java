package com.example.user.homeiotv5;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.EditText;
        import android.widget.Spinner;
        import android.widget.Switch;
        import android.widget.TextView;

        import java.util.ArrayList;
        import java.util.List;

public class ViewRoomActivity extends AppCompatActivity {


    String id;
    int roomID;
    EditText RoomName;
    TextView Temperature, Humidity, Lumosity;
    Switch switch1, switch2, switch3, switch4, switch5, switch6;

    Button Submit;

    Global global;

    Room room;
    TextView RoomType;

    //List<Boolean> switches = new ArrayList<>();
    //List<Boolean> actuator = new ArrayList<>();
    //List<Boolean> roomtype = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_room);

        global = ((Global) getApplicationContext());

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        roomID = intent.getIntExtra("RoomID", -1);
        System.out.println("my id:" + id);

        for (int i = 0; i < global.GlobalRooms.size(); i++) {
            System.out.println("object id is " + global.GlobalRooms.get(i).getId() + "  positipn is " + roomID);

            if (roomID == Integer.parseInt(global.GlobalRooms.get(i).getId()) - 1) {
                room = global.GlobalRooms.get(i);
                break;
            }
        }
        System.out.print("object name is " + room.getName());

        List<String> roomTypeSpinner = new ArrayList<>();

        roomTypeSpinner.add("1");
        roomTypeSpinner.add("2");
        roomTypeSpinner.add("3");
        roomTypeSpinner.add("4");


        for (int i = 0; i < roomTypeSpinner.size(); i++) {
            if (roomTypeSpinner.get(i).equals(room.getType())) {
                roomTypeSpinner.remove(i);
                roomTypeSpinner.add(0, room.getType());
            }
        }


        RoomName = (EditText) findViewById(R.id.roomnameedittext);
        RoomName.setEnabled(false);
        RoomName.setText(room.getName());

        RoomType = findViewById(R.id.dropdown1);
        RoomType.setEnabled(false);
        RoomType.setText(room.getType());

        Temperature =  findViewById(R.id.checkBoxTemperature);
        Temperature.setText("Temperature is " + room.getTemperature());

        Humidity =  findViewById(R.id.checkBoxHumidity);
        Humidity.setText("Humidity is " + room.getTemperature());
        Lumosity =  findViewById(R.id.checkBoxLumosity);
        Lumosity.setText("Luminosity is " + room.getTemperature());
        switch1 = (Switch) findViewById(R.id.switch1);
        switch1.setChecked(transformStringToBoolean(room.getSwitch1()));
        switch2 = (Switch) findViewById(R.id.switch2);
        switch2.setChecked(transformStringToBoolean(room.getSwitch2()));
        switch3 = (Switch) findViewById(R.id.switch3);
        switch3.setChecked(transformStringToBoolean(room.getSwitch3()));
        switch4 = (Switch) findViewById(R.id.switch4);
        switch4.setChecked(transformStringToBoolean(room.getSwitch4()));
        switch5 = (Switch) findViewById(R.id.switch5);
        switch5.setChecked(transformStringToBoolean(room.getSwitch5()));
        switch6 = (Switch) findViewById(R.id.switch6);
        switch6.setChecked(transformStringToBoolean(room.getSwitch6()));
        Submit = (Button) findViewById(R.id.button1);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ViewRoomActivity.this,EditRoomActivity.class).putExtra("RoomID",roomID).putExtra("id",id));
            }
        });

    }

    private Boolean transformStringToBoolean(String string) {
        if(string.equals("false"))
            return false;

        return true;
    }

}

